def Token():
    return ''

